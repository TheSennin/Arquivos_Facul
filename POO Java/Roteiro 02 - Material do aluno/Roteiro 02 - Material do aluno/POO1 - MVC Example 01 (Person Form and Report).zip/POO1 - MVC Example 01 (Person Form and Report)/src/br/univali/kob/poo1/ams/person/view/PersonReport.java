package br.univali.kob.poo1.ams.person.view;

import br.univali.kob.poo1.ams.person.entity.Person;
import java.time.format.DateTimeFormatter;

/**
 * Listagem simples dos empregados cadastrados.
 * Esta classe possui interação com o usuário final.
 *
 * @author Marcello Thiry
 */
public class PersonReport {
    
    /**
     * Dados a serem impressos (pessoas).
     */
    private final Person[] PEOPLE;
    /**
     * Texto do cabeçalho.
     */
    private final String HEADER;
    /**
     * Texto do rodapé.
     */
    private final String FOOTER;
    
    /**
     * @param header o texto do cabeçalho
     * @param footer o texto do rodapé
     * @param people as pessoas a serem impressas
     */
    public PersonReport(String header, String footer, Person[] people) {
        this.HEADER = header;
        this.FOOTER = footer;
        this.PEOPLE = people;
    }
    
    /**
     * Imprime o relatório.
     */
    public void print() {
        printHeader();
        printBody();
        printFooter();
    }
    
    /**
     * Imprime o cabeçalho.
     */
    private void printHeader() {
        System.out.println("\n\n\n\n================================");
        System.out.println(HEADER);
        System.out.println("================================");
        
    }
    
    /**
     * Imprime o corpo principal do relatório.
     */
    private void printBody() {
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        for (Person p : PEOPLE) {
            System.out.format("name: %s\ndate of birth: %s\n", p.getName(), p.getDateOfBirth().format(format));
        }
    }

    /**
     * Imprime o rodapé.
     */
    private void printFooter() {
        System.out.println("================================");
        System.out.println(FOOTER);
    }

}
