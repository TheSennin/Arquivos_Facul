package br.univali.kob.poo1.ams.person.controller;

import br.univali.kob.poo1.ams.person.entity.Person;
import br.univali.kob.poo1.ams.person.view.*;
import br.univali.kob.poo1.ams.persistence.RepositoryManager;
import br.univali.kob.poo1.ams.view.DataTransferObject;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Classe que controla o formulário de entrada de uma pessoa. Esta classe tem 
 * a responsabilidade de coordenar as ações realizadas pelo formulário e 
 * garantir que a implementação adequada seja executada. Esta classe funciona
 * como uma ligação entre a camada de visão (entrada e saída) com a 
 * camada de dados (model).
 * 
 * 
 * (negócio). Tipicamente, estas classes controlam o fluxo de
 * ações que deve ser realizado. 
 * 
 * Aqui, a ideia foi apenas mostrar como ela
 * poderia ser utilizada, pois as chamadas são bastante simples e rígidas.
 *
 * @author Marcello Thiry
 */
public class PersonFormController {

    /**
     * Executa a função principal do controlador que é apresentar o formulário
     * que ele apresenta 
     */
    public void run() {
        // Passando o this como argumento, o formulário de pessoa saberá 
        // como chamar o controlador de volta
        new PersonForm(this).show();
    }

    /**
     * Executa uma ação informada, utilizando os dados passados. O controlador 
     * do formulário poderia processar diferentes ações (save, delete, ...). Os
     * dados são passados da camada view (formulário) para o controlador na 
     * forma de um objeto de transferência de dados (padrão DTO).     * 
     *
     * @param action a ação a ser executada pelo controlador (ex: save)
     * @param data o formulário de entrada com os dados preenchidos pelo usuário
     */
    //public void submit(String action, PersonFormDTO data) {
    public void submit(String action, DataTransferObject data) {
        switch (action) {
            case "save":
                saveAction(data);
        }
    }

    /**
     * Ação para armazenar uma pessoa.
     *
     * @param data o formulário de entrada com os dados preenchidos pelo usuário
     */
    public void saveAction(DataTransferObject data) {
        Person person = new Person();
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        // O formulário encaminha um DTO, no qual a data foi definida como String
        person.setDateOfBirth(LocalDate.parse(data.getData("dateOfBirth"), format));
        person.setName(data.getData("name"));
        RepositoryManager.personRepository().save(person);
    }
}
