package br.univali.kob.poo1.ams.person.view;

import br.univali.kob.poo1.ams.lib.io.Console;
import br.univali.kob.poo1.ams.view.DataTransferObject;
import br.univali.kob.poo1.ams.person.controller.PersonFormController;

/**
 * Tela (formulário) para inclusão de pessoas no sistema.
 * Esta classe possui interação com o usuário final.
 * 
 * @author Marcello Thiry
 */
public class PersonForm {

    /** 
     * Controlador deste formulário.
     */
    private final PersonFormController CTRL;
    /** 
     * Campo do formulário: nome da pessoa.
     */
    private String name;
    /** 
     * Campo do formulário: data de nascimento da pessoa.
     */
    private String dateOfBirth;
    
    /**
     * Construtor do formulário.
     * 
     * @param ctrl o controlador do formulário.
     */
    public PersonForm(PersonFormController ctrl) {
        this.CTRL = ctrl;
    }

    /**
     * Apresenta o formulário para o usuário final iniciar a 
     * interação.
     */
    public void show() {
        boolean continua = true;
        while (continua) {
            read();
            continua = Console.ask("Deseja incluir mais uma pessoa?");
        }
    }
    
    /**
     * Leitura dos dados de uma pessoa.
     * <p>
     * Veja a classe br.univali.kob.poo1.lib.io.Console para conhecer mais
     * sobre como realizar entrada e saída com a classe Scanner.
     */
    private void read() {
        System.out.println("\n\n\nPerson Form");
        System.out.println("-------------");
        name = Console.readlnString("name: ");
        dateOfBirth = Console.readlnString("dateOfBirth (dd/mm/yyyy): ");
        if (Console.ask("Deseja salvar dados informados (s/n)?")) {
           onSaveClick(); 
        } else {
            System.out.println("\n\nOperação cancelada. Dados não foram gravados.");
        }      
    }

    /** 
     * Simula um botão de salvar. Solicita ao repositório que a pessoa seja
     * incluída no sistema.
     */
    private void onSaveClick() {
        // Cria um objeto de transferência (DTO) com os dados informados pelo
        // usuário
        DataTransferObject dto = new DataTransferObject();
        dto.addData("name", name);
        dto.addData("dateOfBirth", dateOfBirth);
        // Submete a ação de salvar para o controlador, passando os dados 
        // encapsulados em um dto
        CTRL.submit("save", dto);
        System.out.println("\n\nDados gravados com sucesso.");
    }
    
}
