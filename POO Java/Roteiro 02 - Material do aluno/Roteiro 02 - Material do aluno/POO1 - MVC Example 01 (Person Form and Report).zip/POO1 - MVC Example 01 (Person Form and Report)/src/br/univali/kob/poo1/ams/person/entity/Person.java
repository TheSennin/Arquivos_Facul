package br.univali.kob.poo1.ams.person.entity;

import java.time.LocalDate;
import java.time.Period;

/**
 * Classe base para hierarquia de pessoas do sistema acadêmico.
 *
 * @author Marcello Thiry
 */
public class Person {

    /**
     * Nome da pessoa.
     */
    private String name;
    /**
     * Data de nascimento da pessoa.
     */
    private LocalDate dateOfBirth;

    /**
     * Construtor default da classe Person. Pode ser redefinido
     * pelas subclasses.
     */
    public Person() {
        // use este espaço para inicializações
    }

     /**
     * Setter.
     *
     * @param name o nome da pessoa
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter.
     *
     * @return o nome da pessoa
     */
    public String getName() {
        return name;
    }

    /**
     * Setter.
     *
     * @param dateOfBirth a data de nascimento da pessoa
     */
    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    /**
     * Getter.
     *
     * @return a data de nascimento da pessoa
     */
    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Simula um Getter, calculando a idade de uma pessoa a partir da
     * data atual.
     *
     * @return a idade da pessoa
     */
    public int getAge() {
        Period period = Period.between(dateOfBirth, LocalDate.now());
        return period.getYears();
    }

}