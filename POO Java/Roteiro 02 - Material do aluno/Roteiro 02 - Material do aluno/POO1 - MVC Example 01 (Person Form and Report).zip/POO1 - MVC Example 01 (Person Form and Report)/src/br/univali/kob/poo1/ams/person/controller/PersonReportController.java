package br.univali.kob.poo1.ams.person.controller;

import br.univali.kob.poo1.ams.persistence.RepositoryManager;
import br.univali.kob.poo1.ams.person.view.PersonReport;

/**
 * Classe de controle (negócio). 
 * Tipicamente, estas classes controlam o fluxo de ações que deve ser realizado.
 * Aqui, a ideia foi apenas mostrar como ela poderia ser utilizada, pois as 
 * chamadas são bastante simples e rígidas.
 * 
 * @author Marcello Thiry
 */
public class PersonReportController {
    
    public void run() {
        PersonReport report = new PersonReport("Person Report", "AMS 1.0", RepositoryManager.personRepository().getAll());
        report.print();
    }
    
}
