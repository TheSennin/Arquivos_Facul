package br.univali.kob.poo1.ams.persistence;

import br.univali.kob.poo1.ams.person.entity.PersonRepository;

/**
 * Gerente geral dos repositórios. A classe conhece os repositórios do sistema
 * e oferece um ponto de acesso a eles.
 * 
 * @author Marcello Thiry
 */
public class RepositoryManager {
    
    /**
     * Repositório de pessoas.
     */
    private static final PersonRepository PERSON_REPOSITORY = new PersonRepository();

    /**
     * Permite que qualquer parte do programa tenha acesso ao repositório
     * único de pessoas.
     * 
     * @return o repositório de pessoas
     */
    public static PersonRepository personRepository() {
        return PERSON_REPOSITORY;
    }
    
}
