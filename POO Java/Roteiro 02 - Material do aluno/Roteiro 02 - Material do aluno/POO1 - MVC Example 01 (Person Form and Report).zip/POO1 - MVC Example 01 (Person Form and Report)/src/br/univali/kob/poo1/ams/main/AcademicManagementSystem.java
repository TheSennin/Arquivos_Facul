package br.univali.kob.poo1.ams.main;

import br.univali.kob.poo1.ams.person.controller.PersonFormController;
import br.univali.kob.poo1.ams.person.controller.PersonReportController;

/**
 * Aplicação simples para mostrar como o código pode ser organizado em 
 * pacotes. Além disso, veja que existem camadas bem definidas, onde as classes
 * que realizam algum processamento nunca fazem entrada e saída com o usuário 
 * final.
 * <p>
 * Para facilitar a visualização da árvore de pacotes no NetBeans, clique com o 
 * botão direito na janela Projects (qualquer área em branco) e selecione a opção
 * [ Exibir Pacotes Java como | Árvore Reduzida ].
 *
 * @author Marcello Thiry
 */
public class AcademicManagementSystem {
    
    /**
     * Neste exemplo, queremos apenas controlar algumas funconalidades 
     * relacionadas a pessoas. As duas funcionalidades são executadas na
     * sequência.
     */    
    public void run() {
        // Executa o cadastro de pessoas
        new PersonFormController().run();
        // Executa o relatório de pessoas
        new PersonReportController().run();
    }
    
    /**
     * O método main(String[] args) é por onde uma aplicação Java inicia. 
     * Embora seja possível que várias classes implementem este método, apenas
     * uma será considerada como a classe principal. Ou seja, o programa 
     * iniciará na primeira linha do método main() da classe principal. 
     * 
     * Este método é estático (operação de classe) e deve ter sempre poucas 
     * linhas de código. Tipicamente, o método inicializa algum objeto que 
     * assumirá o controle da execução do programa.
     * 
     * @param args os argumentos passados via linha de comando (console) - não utilizado aqui
     */        
    public static void main(String[] args) {
        // Cria a classe principal e passa a execução do programa para ela.
        // Neste caso, por ser um exemplo, estamos utilizando esta mesma 
        // classe.
        new AcademicManagementSystem().run();
    }
    
}
