package br.univali.kob.poo1.ams.person.entity;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;

/**
 * Gerencia pessoas cadastrados. Esta classe esconde detalhes sobre como as 
 * pessoas estão armazenadas. Neste primeiro exemplo, estamos armazenando em 
 * um vetor de tamanho fixo e somente em memória. Entretanto, para quem utiliza 
 * este repositório, nada seria alterado se as pessoas fossem recuperadas de 
 * um arquivo ou banco de dados.
 * <p> 
 * Este sistema não implementa validações. Você pode modificar o programa
 * para que ele fique mais robusto (tolerante a entradas incorretas ou 
 * tentativas de quebrar a consistência dos dados). Nas próximas aulas,
 * conheceremos recursos para realizar diversas melhorias neste programa.
 * 
 * @author Marcello Thiry
 */
public class PersonRepository {
    
    /**
     * Armazena as pessoas do repositório. Pode ser final, pois o vetor não
     * pode ser mais modificado depois de criado (apenas seus elementos).
     */
    private final Person[] PEOPLE = new Person[10];
    /**
     * Como é um array, precisamos controlar a quantidade de pessoas
     * cadastradas.
     */
    private int count = 0;
    
    /**
     * Adiciona uma nova pessoa no repositório.
     * 
     * @param person a pessoa a ser adicionada.
     */
    public void save(Person person) {
        PEOPLE[count++] = person;
    }
    
    /**
     * @return a quantidadde de pessoas armazenadas no repositório
     */
    public int count() {
        return count - 1;
    }
    
    /**
     * 
     * @param position a posição que indica a ordem de inclusão da pessoa no
     *                 repositório
     * @return a pessoa que estiver na posição indicada
     */
    public Person get(int position) {
        return PEOPLE[position];
    }
    
    /**
     * @return a lista completa de todas as pessoas do repositório
     */
    public Person[] getAll() {
        // retorna um array com quantidade exata de pessoas armazenadas
        // veja https://docs.oracle.com/javase/8/docs/api/java/util/Arrays.html
        return Arrays.copyOf(PEOPLE, count);
    }

    /**
     * Encontra as pessoas que tiverem um determinado nome.
     * 
     * @param name o nome a ser comparado
     * @return uma lista de pessoas que batem com o nome fornecido
     */
    public Person[] findByName(String name) {
        Person[] matches = new Person[10];
        int found = 0; 
        int matched = 0;
        for (int i = 0; i < count; i++) {
            if (name.equals(PEOPLE[i].getName())) {
               matches[matched++] = PEOPLE[i];
               found++;
            }
        }
        // retorna um array com quantidade exata de pessoas encontradas
        // veja https://docs.oracle.com/javase/8/docs/api/java/util/Arrays.html
        return Arrays.copyOf(matches, found);
    }
       
}

/**
 * Classe criada somente para testes (não faz parte do sistema).
 * 
 * Você testar esta classe separadamente no NetBeans. Basta clicar com o botão
 * diretito sobre qualquer área deste arquivo no editor e selecionar 
 * [ Executar Arquivo ]. Apenas este arquivo será executado, considerando a
 * operação main desta classe.
 */

final class PersonRepositoryLocalTest {

    /**
     * Constante com o formato da data brasileira. 
     */
    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    /**
     * Repositório de teste.
     */
    private static PersonRepository rep = new PersonRepository();
    
    // Simula cadastramento de empregados
    private static void loadPersons() {
        Person p = new Person();
        p.setDateOfBirth(LocalDate.parse("01/01/2000", FORMAT));
        p.setName("Marcello");
        rep.save(p);
        p = new Person();
        p.setDateOfBirth(LocalDate.parse("02/02/2001", FORMAT));
        p.setName("Pedro");
        rep.save(p);
        p = new Person();
        p.setDateOfBirth(LocalDate.parse("03/03/2002", FORMAT));
        p.setName("Marcello");
        rep.save(p);
        p = new Person();
        p.setDateOfBirth(LocalDate.parse("30/04/2003", FORMAT));
        p.setName("Joao");
        rep.save(p);
    }
    
    private static void testFindByName() {
        Person[] people = rep.findByName("Marcello");
        for (Person p : people) {
            System.out.format("name: %s\ndate of birth: %s\n", p.getName(), p.getDateOfBirth().format(FORMAT));
        }
    }
    
    public static void main(String[] args) {
        loadPersons();
        testFindByName();
    }
    
}

