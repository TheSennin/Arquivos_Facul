package br.univali.kob.poo1.ams.view;

import java.util.HashMap;

/**
 * Utiliza o padrão de projeto DTO (Data Transfer Object - Objeto de 
 * Transferência de Dados) para transferir os dados informados pelo usuário
 * para a camada de controle, a partir de uma classe da cadamada de visão 
 * (* ex: formulário). Desta forma, novos campos podem ser adicionados sem
 * que a interface precise ser modificada (o argumento é sempre um DTO).
 *
 * @author Marcello Thiry
 */
public class DataTransferObject {
    
    /**
     * Armazena os pares [chave, valor] do formulário. 
     * 
     * Leia mais sobre a classe java.util.HashMap em: 
     * https://docs.oracle.com/javase/8/docs/api/java/util/HashMap.html
     */
    HashMap map = new HashMap();

    /**
     * Adiciona um campo (fieldName) e seu respectivo valor (fieldValue) informado.
     * 
     * @param fieldName o nome do campo do formulário
     * @param fieldValue o valor preenchido (pelo usuário) para o campo
     */
    public void addData(String fieldName, Object fieldValue) {
        map.put(fieldName, fieldValue);
    }

    /** 
     * Iremos aprender generics (polimorfismo paramétrico) mais tarde. Este é 
     * um método genérico, o qual retorna um objeto (valor) a partir da sua 
     * chave (nome do campo). O tipo de retorno é genérico (T), sendo 
     * identificado automaticamente conforme a classe do objeto valor 
     * encontrado. Note que o retorno faz um cast, uma vez que map é um 
     * HashMap de Object. 
     * 
     * @param <T> o tipo do retorno de acordo com a classe do valor
     * @param fieldName o nome do campo para o qual o valor deve ser retornado
     * @return o valor do campo 
     */
    public <T> T getData (String fieldName) {
        return (T)(map.get(fieldName));
    }
    
}
