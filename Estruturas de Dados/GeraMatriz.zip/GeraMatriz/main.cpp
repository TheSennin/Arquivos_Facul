#include <iostream>

using namespace std;

void geraMatriz(int A[10][10], int linha, int coluna){
    if (linha==coluna)
        for (int j=1; j<=coluna; j++)
            A[linha-1][ j-1]=linha;
    else {
        for (int j=1; j<=coluna; j++)
            A[linha-1][ j-1]=linha;
        geraMatriz(A, linha+1, coluna);
    }
}

int main()
{
    int A[10][10], n;

    cin >> n;

    geraMatriz(A, 1, n);

    for (int i=1; i<=n; i++) {
        for (int j=1; j<=n; j++)
            cout << A[i-1][j-1] << " ";
        cout << endl;
    }

    return 0;
}
