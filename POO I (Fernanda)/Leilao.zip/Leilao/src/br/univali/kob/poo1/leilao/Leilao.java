/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univali.kob.poo1.leilao;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Gustavo
 */
public class Leilao extends Application {
    
    private static Stage stage;
    
    private static Scene loginScene;
    
    private static Scene leiloeiroScene;
    
    private static Scene cadastroScene;
    
    private static Scene participanteScene;
    
    private static Scene cadastroItemScene;
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        stage = primaryStage;
        
        primaryStage.setTitle("Sistema de Leilão");
        
        Parent FXMLLogin = FXMLLoader.load(getClass().getResource("/br/univali/kob/poo1/view/loginScene.fxml"));
        loginScene = new Scene(FXMLLogin);
        
        Parent FXMLleiloeiro = FXMLLoader.load(getClass().getResource("/br/univali/kob/poo1/view/leiloeiroScene.fxml"));
        leiloeiroScene = new Scene(FXMLleiloeiro);
        
        Parent FXMLCadastro = FXMLLoader.load(getClass().getResource("/br/univali/kob/poo1/view/cadastroScene.fxml"));
        cadastroScene = new Scene(FXMLCadastro);
        
        Parent FXMLParticipante = FXMLLoader.load(getClass().getResource("/br/univali/kob/poo1/view/participanteScene.fxml"));
        participanteScene = new Scene(FXMLParticipante);
                
        Parent FXMLCadastroItem = FXMLLoader.load(getClass().getResource("/br/univali/kob/poo1/view/cadastroItemScene.fxml"));
        cadastroItemScene = new Scene(FXMLCadastroItem);
        
        primaryStage.setScene(loginScene);
        primaryStage.show();
    }
    
    public static void changeScreen(String scr){
        switch(scr){
            case "loginScene":
                stage.setScene(loginScene);
                break;
            case "leiloeiroScene":
                stage.setScene(leiloeiroScene);
                break;
            case "cadastroScene":
                stage.setScene(cadastroScene);
                break;
            case "participanteScene":
                stage.setScene(participanteScene);
                break;
            case "cadastroItemScene":
                stage.setScene(cadastroItemScene);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
