/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univali.kob.poo1.leilao;

import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author Gustavo
 */
public class Login {
    
    /**
     * Lista que armazenará todos os usuarios
     */
    private ArrayList<Usuario> usuarios = new ArrayList();
    
    public Login(){
        try {
            usuarios = UsuarioRepositorio.Read();
        } catch (IOException | ClassNotFoundException e) {
            e.getMessage();
        }
    }
    
    public boolean PesquisarLoginSenha(String login, String senha){
        for(int i=0;i<usuarios.size();i++){ //Percorre a lista de usuarios
            if(usuarios.get(i).getLogin().equals(login)){ //Checa se o login passado pelo usuario bate com algum login da lista
                if(usuarios.get(i).getSenha().equals(senha)){ //Checa se a senha bate com a senha do usuario atual
                    if(usuarios.get(i).getTipo().equals("Participante")){ 
                        Leilao.changeScreen("participanteScene"); //Se o tipo de login for de participante, vai para a tela de participante
                        return true;
                    }else{
                        Leilao.changeScreen("leiloeiroScene"); //Senão, vai para a tela de leiloeiro
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    /**
     * Método para registrar novos usuarios
     * @param user usuario recem registrado que será persistido no arquivo
     */
    public void persistirUsuario(Usuario user){
        usuarios.add(user);
        UsuarioRepositorio.Write(usuarios);
    }
    
    
}
