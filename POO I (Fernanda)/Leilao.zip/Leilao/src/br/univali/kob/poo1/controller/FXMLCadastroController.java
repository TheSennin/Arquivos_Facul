/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univali.kob.poo1.controller;

import br.univali.kob.poo1.leilao.Login;
import br.univali.kob.poo1.leilao.Usuario;
import br.univali.kob.poo1.leilao.Leilao;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

/**
 * FXML Controller class
 *
 * @author Gustavo
 */
public class FXMLCadastroController implements Initializable {

    @FXML
    private TextField txtLogin;

    @FXML
    private Button btnVoltar;

    @FXML
    private Button btnCadastrar;

    @FXML
    private TextField txtNome;

    @FXML
    private TextField txtEmail;

    @FXML
    private PasswordField txtPw;
    
    @FXML
    private Label lblSucessoCadastro;
    
    @FXML
    private Label lblErroCadastro;
    
    @FXML
    private ToggleGroup grupo;
    
    @FXML
    private void btnVoltarAction(ActionEvent event){
        Leilao.changeScreen("loginScene");
    }
    
    @FXML
    private void radParticipanteAction(ActionEvent event){
        RadioButton rad = (RadioButton) grupo.getSelectedToggle();
    }
    
    @FXML
    private void btnCadastrarAction(ActionEvent event){
        RadioButton rad = (RadioButton) grupo.getSelectedToggle();
        String nome, email, login, senha, tipo;
        nome = txtNome.getText();
        email = txtEmail.getText();
        login = txtLogin.getText();
        senha = txtPw.getText();
        tipo = rad.getText();
        try{
            Usuario usuario = new Usuario(nome, email, login, senha, tipo);
            Login log = new Login();
            log.persistirUsuario(usuario);
            lblSucessoCadastro.setText("CADASTRADO COM SUCESSO!");
            
        }catch(Exception e){
           lblErroCadastro.setText("ERRO AO CADASTRAR!");
        }
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
