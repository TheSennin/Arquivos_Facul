/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univali.kob.poo1.leilao;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Gustavo
 */
public class Usuario implements Serializable{
    /**
     * Nome do usuario
     */
    private String nome;
    /**
     * Email do usuario
     */
    private String email;
    /**
     * Login do usuario
     */
    private String login;
    /**
     * senha do usuario
     */
    private String senha;
    /**
     * Tipo de usuario
     */
    private String tipo;
    
    /**
     * Lista de itens leiloados pelo usuario
     */
    private ArrayList<Item> itensAnunciados = new ArrayList();
    
    public Usuario(){
        //Construtor vazio para criaçao de objeto nulo, apenas para ser instanciado
    }
    /**
     * Construtor default
     * @param nome o nome do usuario
     * @param email o email do usuario
     */
    public Usuario(String nome, String email){
        setNome(nome);
        setEmail(email);
    }
    /**
     * Construtor telescoping
     * UsuarioRepositorio.write está persistindo o login e senha no arquivo
     * @param nome
     * @param email
     * @param login
     * @param senha 
     */
    public Usuario(String nome, String email, String login, String senha, String tipo){
        this(nome, email);
        setLogin(login);
        setSenha(senha);
        setTipo(tipo);
    }
    
    /**
     * Define o tipo de usuario
     */
    public void setTipo(String tipo){
        this.tipo = tipo;
    }
    
    /**
     * @return o tipo de usuario
     */
    public String getTipo(){
        return this.tipo;
    }

    /**
     * @return o nome do usuario
     */
    public String getNome() {
        return this.nome;
    }

    /**
     * define o nome do usuario
     * @param nome o nome do usuario
     */
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    /**
     * @return o nome do usuario
     */
    public String getEmail() {
        return this.email;
    }

    /**
     * define o email do usuario
     * @param email o email do usuario
     */
    public void setEmail(String email) {
        this.email = email;
    }
/**
     * @return o login do usuario
     */
    public String getLogin() {
        return this.login;
    }

    /**
     * Define o login do usuario
     * @param login 
     */
    public void setLogin(String login) {
        this.login = login;
    }
    
    /**
     * @return o login do usuario
     */
    public String getSenha() {
        return this.senha;
    }
    
    /**
     * Define a senha do usuario
     * @param senha 
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }
    /**
     * Adiciona itens anunciados pelo usuario
     * @param item
     */
    public void addItens(Item item){
        itensAnunciados.add(item);
    }
    
}
