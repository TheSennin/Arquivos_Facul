/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univali.kob.poo1.leilao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Gustavo
 */
public class UsuarioRepositorio implements Serializable {
    
    public static void Write(ArrayList u){
        try{
            FileOutputStream arq = new FileOutputStream("UsuarioRepositorio");
            ObjectOutputStream obj = new ObjectOutputStream(arq);
            obj.writeObject(u);
            obj.flush();
            obj.close();
            System.out.println("Sucesso ao gravar o usuario no arquivo!");
        }catch(IOException e){
            System.out.println("Erro ao gravar o usuario no arquivo.");
        }
    }
    public static ArrayList Read() throws FileNotFoundException, IOException, ClassNotFoundException{
        ArrayList<Usuario> a = new ArrayList();
        try{
            FileInputStream arq = new FileInputStream("UsuarioRepositorio");
            ObjectInputStream obj = new ObjectInputStream(arq);
            a = (ArrayList)obj.readObject();
            obj.close();
            System.out.println("Banco de usuarios lido com sucesso!");
        }catch(FileNotFoundException e){
            System.out.println("Banco de usuarios não encontrado!");
        }
        return a;   
    }
}
