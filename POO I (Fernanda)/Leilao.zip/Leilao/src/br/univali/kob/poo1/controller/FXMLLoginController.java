/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univali.kob.poo1.controller;

import br.univali.kob.poo1.leilao.Login;
import br.univali.kob.poo1.leilao.Leilao;
import br.univali.kob.poo1.leilao.Usuario;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 *
 * @author Gustavo
 */
public class FXMLLoginController implements Initializable {
    
    @FXML
    private Button btnLogin;

    @FXML
    private Label lblWrongLogin;
    
    @FXML
    private PasswordField pwField;
    
    @FXML
    private TextField loginField;
    
     @FXML
    private Hyperlink hyperLeiloeiro;
     
     @FXML
    private Hyperlink hyperCadastro;
    
    @FXML
    private void btnLoginAction(ActionEvent event) {
        Login login = new Login();
        Usuario usuario = new Usuario();
        String log = loginField.getText();
        String senha = pwField.getText();
        if(!login.PesquisarLoginSenha(log, senha)){
            lblWrongLogin.setText("Login ou Senha incorretos.\nTente novamente.");
        }else{
            lblWrongLogin.setText("");
        }
    }
    
    @FXML
    private void hyperCadastroAction(ActionEvent event){
        Leilao.changeScreen("cadastroScene");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
