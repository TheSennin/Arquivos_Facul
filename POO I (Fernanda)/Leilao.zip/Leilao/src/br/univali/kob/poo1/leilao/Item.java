/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univali.kob.poo1.leilao;

import java.io.Serializable;

/**
 *
 * @author Gustavo
 */
public class Item implements Serializable{
    
    private String titulo;
    private String descricao;
    private String ano;
    private String quantidade;
    private String lanceInicial;
    private Usuario arrematado;
    
    /**
     * Construtor default
     * @param titulo titulo do item a ser leioado
     * @param descricao descrição do item a ser leiloado
     * @param ano ano de fabricação do item
     * @param quantidade quantidade ofertada pelo leiloeiro
     * @param lanceInicial lance inicial do item
     */
    public Item(String titulo, String descricao, String ano, String quantidade, String lanceInicial){
        setTitulo(titulo);
        setDescricao(descricao);
        setAno(ano);
        setQuantidade(quantidade);
        setLanceInicial(lanceInicial);
    }

    /**
     * 
     * @return o ano de fabricação do item
     */
    public String getAno() {
        return ano;
    }
    
    /**
     * Define o ano de fabricação do item
     * @param ano 
     */
    public void setAno(String ano) {
        this.ano = ano;
    }

    /**
     * 
     * @return a descriçao do item ofertado
     */
    public String getDescricao() {
        return descricao;
    }

    /**
     * Define a descriçao do item
     * @param descricao 
     */
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    /**
     * 
     * @return o titulo do item ofertado
     */
    public String getTitulo() {
        return this.titulo;
    }

    /**
     * Define o titulo do item
     * @param titulo 
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * 
     * @return a quantidade ofertada do item
     */
    public String getQuantidade() {
        return this.quantidade;
    }

    /**
     * Define a quantidade do item
     * @param quantidade 
     */
    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }

    /**
     * 
     * @return o lance inicial 
     */
    public String getLanceInicial() {
        return this.lanceInicial;
    }

    /**
     * Define o lance inicial
     * @param lanceInicial 
     */
    public void setLanceInicial(String lanceInicial) {
        this.lanceInicial = lanceInicial;
    }
    
    public void setArrematado(Usuario usuario){
        arrematado = usuario;
    }
    
    public Usuario getArrematado(){
        return arrematado;
    }
    
    /**
     * 
     * @return uma string com todas as informaçoes a serem mostradas na tela
     */
    @Override
    public String toString(){
        StringBuilder output = new StringBuilder();
        
        output.append("\r\nTitulo: ").append(getTitulo());
        output.append("\r\nDescricao: ").append(getDescricao());
        output.append("\r\nAno de Fabricação: ").append(getAno());
        output.append("\r\nQuantidade: ").append(getQuantidade());
        output.append("\r\nPreço: ").append(getLanceInicial());
        output.append("\r\n-----------------------");
        return output.toString();
    }  
}
