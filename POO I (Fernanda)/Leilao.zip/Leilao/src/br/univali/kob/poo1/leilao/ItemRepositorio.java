/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univali.kob.poo1.leilao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Gustavo
 */
public class ItemRepositorio implements Serializable {
    
    public static void Write(ArrayList u){
        try{
            FileOutputStream arq = new FileOutputStream("ItemRepositorio");
            ObjectOutputStream obj = new ObjectOutputStream(arq);
            obj.writeObject(u);
            obj.flush();
            obj.close();
            System.out.println("Sucesso ao gravar o item no arquivo!");
        }catch(IOException e){
            System.out.println("Erro ao gravar o item no arquivo.");
        }
    }
    public static ArrayList Read() throws FileNotFoundException, IOException, ClassNotFoundException{
        ArrayList<Item> a = new ArrayList();
        try{
            FileInputStream arq = new FileInputStream("ItemRepositorio");
            ObjectInputStream obj = new ObjectInputStream(arq);
            a = (ArrayList)obj.readObject();
            obj.close();
            System.out.println("Banco de itens lido com sucesso!");
        }catch(FileNotFoundException e){
            System.out.println("Banco de itens não encontrado!");
        }
        return a;   
    }
}
