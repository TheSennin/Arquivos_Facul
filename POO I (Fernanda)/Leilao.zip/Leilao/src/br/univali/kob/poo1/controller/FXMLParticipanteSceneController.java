/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univali.kob.poo1.controller;

import br.univali.kob.poo1.leilao.Item;
import br.univali.kob.poo1.leilao.Leilao;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author 6322875
 */
public class FXMLParticipanteSceneController implements Initializable {
     @FXML
    private TextArea txtDescricao;

    @FXML
    private ListView<Item> lvItens;

    @FXML
    private TextArea txtAno;

    @FXML
    private TextField txtQuantidade;

    @FXML
    private TextField txtLanceMin;

    @FXML
    private Button btnEfetuarLance;

    @FXML
    private TextField txtEfetuarLance;
    
    private ArrayList<Item> itens = new ArrayList();
    
    private ObservableList<Item> obsItem;
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @FXML
    private void btnEfetuarLanceAction(ActionEvent event){
        
    }
    
    @FXML
    private void btnSairAction(ActionEvent event){
        Leilao.changeScreen("loginScene");
    }
    
}
