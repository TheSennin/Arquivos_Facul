package br.univali.kob.poo.clube;

public enum Categoria {
    BASIC(199.00,0.10),
    PLUS(299.00,0.15),
    ULTRA(349.00,0.10),
    VIP(399.00,0.15);
    private final double valor;
    private final double porcentagemDependente;

    Categoria(double valor, double porcentagemDependente) {
        this.valor = valor;
        this.porcentagemDependente = porcentagemDependente;
    }

    public double getValor() {
        return valor;
    }

    public double getPorcentagemDependente() {
        return porcentagemDependente;
    }
}
