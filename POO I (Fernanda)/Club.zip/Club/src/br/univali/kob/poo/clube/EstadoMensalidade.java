package br.univali.kob.poo.clube;

public enum EstadoMensalidade {
    ABERTO,
    PAGO,
    ATRASADO;
}
