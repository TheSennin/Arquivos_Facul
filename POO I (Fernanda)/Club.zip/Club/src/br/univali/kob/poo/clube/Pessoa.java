package br.univali.kob.poo.clube;

public abstract class Pessoa {
    private final String numeroDoCartao;
    private final String nome;
    private final String email;

    public Pessoa(String numeroDoCartao, String nome, String email) {
        this.numeroDoCartao = numeroDoCartao;
        this.nome = nome;
        this.email = email;
    }

    public String getNumeroDoCartao() {
        return numeroDoCartao;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }
}
