package br.univali.kob.poo.clube;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.Month;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Stack;
import java.util.stream.Collectors;

public class Sócio extends Pessoa {
    private static int ID = 0;
    private final int id;
    private final Stack<Mensalidade> mensalidades;
    private final HashSet<Dependente> dependentes;
    private Categoria categoria;
    private int diaVencimento;

    public Sócio(String numeroDoCartao, String nome, String email,Categoria categoria,int diaVencimento, Dependente... dependentes) {
        super(numeroDoCartao, nome, email);
        ID++;
        id = ID;
        mensalidades = new Stack<>();
        this.dependentes = new HashSet<>();
        addDependente(dependentes);
        this.categoria = categoria;
        setDiaVencimento(diaVencimento);
        gerarMensalidade();
    }

    private void validadeDia(){
        if(diaVencimento > 31 || diaVencimento < 1){
            throw new IllegalArgumentException("Dia do vencimento não está entre o limite de 1|--|31");
        }
    }

    private LocalDate tryData(int year, Month month, int day){
        try {
            return LocalDate.of(year, month, day);
        }catch (DateTimeException e){
            return tryData(year, month,day-1);
        }
    }

    public List<Mensalidade> getMensalidadeByEstado(EstadoMensalidade estado){
        return mensalidades.stream().filter(mensalidade -> mensalidade.getEstado().equals(estado)).collect(Collectors.toList());
    }

    public List<Mensalidade> getHistoricoMensalidades(){
        return mensalidades;
    }

    public Mensalidade getUltimaMensalidade(){
        return mensalidades.peek();
    }

    public void gerarMensalidade(){
        LocalDate now = LocalDate.now();
        Mensalidade newM = new Mensalidade(tryData(now.getYear(),now.getMonth(),diaVencimento),dependentes.size(),categoria);
        if(!mensalidades.contains(newM)){
            mensalidades.push(newM);
        }
    }

    public int getDiaVencimento() {
        return diaVencimento;
    }

    public void setDiaVencimento(int diaVencimento) {
        this.diaVencimento = diaVencimento;
        validadeDia();
    }

    public void addDependente(Dependente... dependentes){
        this.dependentes.addAll(Arrays.asList(dependentes));
    }

    public void removerDependente(Dependente dependente){
        dependentes.remove(dependente);
    }

    public int getId() {
        return id;
    }

    public List<Mensalidade> getMensalidade() {
        return (List<Mensalidade>) mensalidades.clone();
    }

    public HashSet<Dependente> getDependentes() {
        return (HashSet<Dependente>) dependentes.clone();
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }
}