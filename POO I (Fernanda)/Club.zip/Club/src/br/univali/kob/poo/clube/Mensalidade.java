package br.univali.kob.poo.clube;

import java.time.LocalDate;

public class Mensalidade {
    private final LocalDate vencimento;
    private final double valor;
    private final int numeroDepemdente;
    private final Categoria categoria;
    private EstadoMensalidade estado;

    public Mensalidade(LocalDate vencimento, int numeroDepemdente, Categoria categoria) {
        this.vencimento = vencimento;
        this.numeroDepemdente = numeroDepemdente;
        this.categoria = categoria;
        estado = EstadoMensalidade.ABERTO;
        valor = categoria.getValor()*numeroDepemdente*categoria.getPorcentagemDependente() + categoria.getValor();
    }

    public void verificarEstado(){
        if(estado == EstadoMensalidade.ABERTO && vencimento.isBefore(LocalDate.now())){
            estado = EstadoMensalidade.ATRASADO;
        }
    }

    public void pagar(){
        estado = EstadoMensalidade.PAGO;
    }

    public LocalDate getVencimento() {
        return vencimento;
    }

    public double getValor() {
        return valor;
    }

    public int getNumeroDepemdente() {
        return numeroDepemdente;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public EstadoMensalidade getEstado() {
        return estado;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Mensalidade that = (Mensalidade) o;
        return that.vencimento.equals(vencimento);
    }

    @Override
    public int hashCode() {
        return vencimento.hashCode() ^
               Double.hashCode(valor) ^
               numeroDepemdente ^
               categoria.hashCode() ^
               estado.hashCode();
    }

    @Override
    public String toString() {
        return "Mensalidade{" +
                "vencimento=" + vencimento +
                ", valor=" + valor +
                ", numeroDepemdente=" + numeroDepemdente +
                ", categoria=" + categoria +
                ", estado=" + estado +
                '}';
    }
}
