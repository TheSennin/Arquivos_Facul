package br.univali.kob.poo.clube;

public class Main {

    public static void main(String[] args) {
        Dependente dependente = new Dependente("000-020-340","dependente","email","pai");
	    Sócio so = new Sócio("012-345-678","sócio","email",Categoria.BASIC,31,dependente);
	    so.setCategoria(Categoria.PLUS);
	    so.gerarMensalidade();
	    so.getUltimaMensalidade().pagar();
        System.out.println(so.getMensalidade());
    }
}
