package br.univali.kob.poo.clube;

public class Dependente extends Pessoa {
    private final String parentesco;

    public Dependente(String numeroDoCartao, String nome, String email, String parentesco) {
        super(numeroDoCartao, nome, email);
        this.parentesco = parentesco;
    }

    public String getParentesco() {
        return parentesco;
    }
}
