import br.univali.kob.poo.catalogo.itens.*;
import br.univali.kob.poo.catalogo.repository.ItemsRepository;
import java.io.IOException;
import java.time.LocalDate;

public class Main {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        ItemsRepository repository = new ItemsRepository("src/data/Items.DAT");
        int count = 0;
        for (int i=0;i<2;i++) {
            for (int j=0;j<3;j++) {
                int value = (i+j)+1;
                count++;
                Book book = new Book(new ItemBean("book"+i,
                                                   LocalDate.of(2000+j, value, count),
                                                  "author"+i, "author"+j),
                                     "house"+count,
                                      LocalDate.of(2005+i, value, count));
                value++;count++;
                CD cd = new CD(new ItemBean("cd"+count,
                                             LocalDate.of(2000+value, value, count),
                                             "author"+i, "author"+j),
                              "gender"+count,
                              "track"+value, "track"+i);
                value++;count++;
                DVD dvd = new DVD(new ItemBean("dvd"+j,
                                               LocalDate.of(2000+count, value, count),
                                              "author"+i, "author"+j),
                                 "type"+count,
                                 "description"+value);
                value++;count++;
                Magazine magazine = new Magazine(new ItemBean("magazine"+i,
                                                               LocalDate.of(2000+j, value, count),
                                                              "author"+i, "author"+j),
                                                "house"+i,
                                                 LocalDate.of(2000+j, value, count),
                                                count+i,
                                                "Topic"+j,"Topic"+value);
                repository.save(book);
                repository.save(cd);
                repository.save(dvd);
                repository.save(magazine);
            }
        }
        System.out.println(repository.findAll().toString());
    }
}
