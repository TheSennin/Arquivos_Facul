package br.univali.kob.poo.catalogo.repository;

import br.univali.kob.poo.catalogo.itens.Book;
import br.univali.kob.poo.catalogo.itens.ItemCol;
import br.univali.kob.poo.catalogo.itens.Magazine;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface FindableByBook{
    List<ItemCol> findAll();

    default List<Book> findBook(){
        ArrayList<Book> books = new ArrayList<>();
        for (ItemCol item : findAll()) {
            if (item instanceof Book && !(item instanceof Magazine)) {
                books.add((Book) item);
            }
        }
        return books;
    }

    default List<Book> findByPublishingHouse(String publishingHouse){
        return findBook().stream().filter(book -> book.getPublishingHouse().equals(publishingHouse)).collect(Collectors.toList());
    }

    default List<Book> findByPublicationDate(LocalDate publicationDate){
        return findBook().stream().filter(book -> book.getPublicationDate().equals(publicationDate)).collect(Collectors.toList());
    }
}
