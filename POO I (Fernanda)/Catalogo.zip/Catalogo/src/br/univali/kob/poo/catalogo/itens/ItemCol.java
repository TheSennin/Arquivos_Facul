package br.univali.kob.poo.catalogo.itens;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

public abstract class ItemCol implements Serializable {
    private static int ID = 0;
    private final int id;
    private final String name;
    private final LocalDate buyDate;
    private final ArrayList<String> author;

    public ItemCol(ItemBean bin) {
        ID++;
        this.id = ID;
        this.name = bin.getName();
        this.buyDate = bin.getBuyDate();
        this.author = bin.getAuthor();
    }

    public final int getId() {
        return id;
    }

    public final String getName() {
        return name;
    }

    public final LocalDate getBuyDate() {
        return buyDate;
    }

    public final ArrayList<String> getAuthor() {
        return (ArrayList<String>) author.clone();
    }

    @Override
    public String toString() {
        return  "id=" + id +
                ", name='" + name + '\'' +
                ", buyDate=" + buyDate +
                ", author=" + author;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ItemCol itemCol = (ItemCol) o;
        return id == itemCol.id &&
                name.equals(itemCol.name) &&
                buyDate.equals(itemCol.buyDate) &&
                author.equals(itemCol.author);
    }

    @Override
    public int hashCode() {
        return id ^ name.hashCode() ^ buyDate.hashCode() ^ author.hashCode();
    }
}
