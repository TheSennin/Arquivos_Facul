package br.univali.kob.poo.catalogo.itens;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;

public final class ItemBean {
    private final String name;
    private final LocalDate buyDate;
    private final ArrayList<String> author;

    public ItemBean(String name, LocalDate buyDate, String... author) {
        this.name = name;
        this.buyDate = buyDate;
        this.author = new ArrayList<>();
        this.author.addAll(Arrays.asList(author));
    }

    public final String getName() {
        return name;
    }

    public final LocalDate getBuyDate() {
        return buyDate;
    }

    public final ArrayList<String> getAuthor() {
        return author;
    }
}
