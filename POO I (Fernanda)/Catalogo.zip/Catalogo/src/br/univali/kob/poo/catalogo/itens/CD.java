package br.univali.kob.poo.catalogo.itens;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public final class CD extends ItemCol implements Serializable {
    private final String gender;
    private final ArrayList<String> trackList;

    public CD(ItemBean bin, String gender, String... trackList) {
        super(bin);
        this.gender = gender;
        this.trackList = new ArrayList<>();
        this.trackList.addAll(Arrays.asList(trackList));
    }

    public String getGender() {
        return gender;
    }

    public ArrayList<String> getTrackList() {
        return (ArrayList<String>) trackList.clone();
    }

    @Override
    public String toString() {
        return "\nCD{" + super.toString() +
                ", gender='" + gender + '\'' +
                ", trackList=" + trackList + "}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CD cd = (CD) o;
        return gender.equals(cd.gender) && trackList.equals(cd.trackList) && super.equals(o);
    }

    @Override
    public int hashCode() {
        return super.hashCode() ^ gender.hashCode() ^ trackList.hashCode();
    }
}
