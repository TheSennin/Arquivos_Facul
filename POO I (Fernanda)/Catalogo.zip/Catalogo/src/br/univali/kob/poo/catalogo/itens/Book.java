package br.univali.kob.poo.catalogo.itens;

import java.io.Serializable;
import java.time.LocalDate;

public class Book extends ItemCol implements Serializable {
    private final String publishingHouse;
    private final LocalDate publicationDate;

    public Book(ItemBean bin, String publishingHouse, LocalDate publicationDate) {
        super(bin);
        this.publishingHouse = publishingHouse;
        this.publicationDate = publicationDate;
    }

    public final String getPublishingHouse() {
        return publishingHouse;
    }

    public final LocalDate getPublicationDate() {
        return publicationDate;
    }

    @Override
    public String toString() {
        return "\nBook{" + super.toString() +
                ", publishingHouse='" + publishingHouse + '\'' +
                ", publicationDate=" + publicationDate + "}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Book book = (Book) o;
        return publishingHouse.equals(book.publishingHouse) && publicationDate.equals(book.publicationDate) && super.equals(o);
    }

    @Override
    public int hashCode() {
        return publishingHouse.hashCode() ^ publicationDate.hashCode() ^ super.hashCode();
    }
}
