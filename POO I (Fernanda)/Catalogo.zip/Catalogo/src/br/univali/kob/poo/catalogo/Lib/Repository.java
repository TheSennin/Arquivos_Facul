package br.univali.kob.poo.catalogo.Lib;

import br.univali.kob.poo.catalogo.itens.ItemCol;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public abstract class Repository<T> {
    
    private final String FILENAME;
    private List<T> ELEMENTS;

    public Repository(String fileName) throws IOException, ClassNotFoundException {
        this.FILENAME = fileName;
        loadAll();
    }

    public void save(T element) throws IOException {
        int index = find(element);
        if (index >= 0) {
            ELEMENTS.set(index, element);
        } else {
            ELEMENTS.add(element);
        }
        saveAll();
    }

    public void delete(T element) throws IOException {
        ELEMENTS.remove(element);
        saveAll();
    }

    public boolean contains(T element) {
        return ELEMENTS.contains(element);
    }

    public List<T> findAll() {
        return ELEMENTS;
    }

    protected int find(T element) {
        return ELEMENTS.indexOf(element);
    }

    private void loadAll() throws IOException, ClassNotFoundException {
        try (InputStream file = new FileInputStream(FILENAME);
             InputStream buffer = new BufferedInputStream(file);
             ObjectInput input = new ObjectInputStream(buffer)){
                ELEMENTS = (List<T>) input.readObject();
        } catch (FileNotFoundException ex) {
            ELEMENTS = new ArrayList<>(); 
        }
    }

    private void saveAll() throws IOException {
        try (OutputStream file = new FileOutputStream(FILENAME);
             OutputStream buffer = new BufferedOutputStream(file);
             ObjectOutput output = new ObjectOutputStream(buffer)) {
                output.writeObject(ELEMENTS);
        }
    }

}
