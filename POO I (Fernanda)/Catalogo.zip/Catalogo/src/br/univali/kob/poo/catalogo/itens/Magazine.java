package br.univali.kob.poo.catalogo.itens;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;

public final class Magazine extends Book implements Serializable {
    private final int volume;
    private final ArrayList<String> mainTopic;

    public Magazine(ItemBean bin, String publishingHouse, LocalDate publicationDate, int volume, String... mainTopic) {
        super(bin, publishingHouse, publicationDate);
        this.volume = volume;
        this.mainTopic = new ArrayList<>();
        this.mainTopic.addAll(Arrays.asList(mainTopic));
    }

    public int getVolume() {
        return volume;
    }

    public ArrayList<String> getMainTopic() {
        return (ArrayList<String>) mainTopic.clone();
    }

    @Override
    public String toString() {
        return "\nMagazine{" + super.toString() +
                "volume='" + volume + '\'' +
                ", mainTopic='" + mainTopic + '\'' +"}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Magazine magazine = (Magazine) o;
        return volume == magazine.volume && mainTopic.equals(magazine.mainTopic) && super.equals(o);
    }

    @Override
    public int hashCode() {
        return super.hashCode() ^ volume ^ mainTopic.hashCode();
    }
}
