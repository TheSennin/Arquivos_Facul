package br.univali.kob.poo.catalogo.itens;

import java.io.Serializable;

public final class DVD extends ItemCol implements Serializable {
    private final String type;
    private final String description;

    public DVD(ItemBean bin, String type, String description) {
        super(bin);
        this.type = type;
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return "\nDVD{" + super.toString() +
                "type='" + type + '\'' +
                ", description='" + description + '\'' +"}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DVD dvd = (DVD) o;
        return type.equals(dvd.type) && description.equals(dvd.description) && super.equals(o);
    }

    @Override
    public int hashCode() {
        return super.hashCode() ^ type.hashCode() ^ description.hashCode();
    }
}
