package br.univali.kob.poo.catalogo.repository;

import br.univali.kob.poo.catalogo.itens.ItemCol;
import br.univali.kob.poo.catalogo.itens.Magazine;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public interface FindableByMagazine {
    List<ItemCol> findByName(String name);
    List<ItemCol> findAll();

    default List<Magazine> findMagazine(){
        ArrayList<Magazine> magazines = new ArrayList<>();
        for (ItemCol item : findAll()) {
            if (item instanceof Magazine) {
                magazines.add((Magazine) item);
            }
        }
        return magazines;
    }

    default List<Magazine> findByVolume(int volume){
        return findMagazine().stream().filter(magazine -> magazine.getVolume() == volume).collect(Collectors.toList());
    }

    default List<Magazine> findByMainTopic(String... mainTopic){
        return findMagazine().stream().filter(magazine -> magazine.getMainTopic().containsAll(Arrays.asList(mainTopic))).collect(Collectors.toList());
    }

    default List<Magazine> findByNameAndVolume(String name, int volume){
        return findByVolume(volume).stream().filter(magazine -> magazine.getName().equals(name)).collect(Collectors.toList());
    }
}
