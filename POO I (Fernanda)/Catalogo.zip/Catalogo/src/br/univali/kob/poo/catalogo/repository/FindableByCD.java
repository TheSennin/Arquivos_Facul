package br.univali.kob.poo.catalogo.repository;

import br.univali.kob.poo.catalogo.itens.CD;
import br.univali.kob.poo.catalogo.itens.ItemCol;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public interface FindableByCD {
    List<ItemCol> findAll();

    default List<CD> findCD(){
        ArrayList<CD> CDs = new ArrayList<>();
        for (ItemCol item : findAll()) {
            if (item instanceof CD) {
                CDs.add((CD) item);
            }
        }
        return CDs;
    }

    default List<CD> findByGender(String gender){
        return findCD().stream().filter(cd -> cd.getGender().equals(gender)).collect(Collectors.toList());
    }

    default List<CD> findByTrack(String... track){
        return findCD().stream().filter(cd -> cd.getTrackList().addAll(Arrays.asList(track))).collect(Collectors.toList());
    }
}
