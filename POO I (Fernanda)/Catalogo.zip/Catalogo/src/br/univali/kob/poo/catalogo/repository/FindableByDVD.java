package br.univali.kob.poo.catalogo.repository;

import br.univali.kob.poo.catalogo.itens.DVD;
import br.univali.kob.poo.catalogo.itens.ItemCol;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface FindableByDVD {
    List<ItemCol> findAll();

    default List<DVD> findDVD(){
        ArrayList<DVD> DVDs = new ArrayList<>();
        for (ItemCol item : findAll()) {
            if (item instanceof DVD) {
                DVDs.add((DVD) item);
            }
        }
        return DVDs;
    }

    default List<DVD> findByType(String type){
        return findDVD().stream().filter(dvd -> dvd.getType().equals(type)).collect(Collectors.toList());
    }

    default List<DVD> findByDescription(String description){
        return findDVD().stream().filter(dvd -> dvd.getDescription().equals(description)).collect(Collectors.toList());
    }
}
