package br.univali.kob.poo.catalogo.repository;

import br.univali.kob.poo.catalogo.itens.ItemCol;
import br.univali.kob.poo.catalogo.Lib.Repository;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ItemsRepository extends Repository<ItemCol> implements FindableByBook, FindableByMagazine, FindableByCD, FindableByDVD {
    public ItemsRepository(String fileName) throws IOException, ClassNotFoundException {
        super(fileName);
    }

    public ItemCol findById(int id){
        return findAll().stream().filter(itemCol -> itemCol.getId() == id).findFirst().orElse(null);
    }

    public List<ItemCol> findByName(String name){
        return findAll().stream().filter(itemCol -> itemCol.getName().equals(name)).collect(Collectors.toList());
    }

    public List<ItemCol> findByBuyDate(LocalDate buyDate){
        return findAll().stream().filter(itemCol -> itemCol.getBuyDate().equals(buyDate)).collect(Collectors.toList());
    }

    public List<ItemCol> findByAuthor(String... author){
        return findAll().stream().filter(itemCol -> itemCol.getAuthor().containsAll(Arrays.asList(author))).collect(Collectors.toList());
    }
}
