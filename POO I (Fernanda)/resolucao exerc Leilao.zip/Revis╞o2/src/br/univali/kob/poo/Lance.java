package br.univali.kob.poo;

import java.time.LocalTime;

public final class Lance {
    private final double val_lance;
    private final LocalTime hora_lance;
    private final Participante participante;

    public Lance(double val_lance, Participante participante) {
        this.val_lance = val_lance;
        this.hora_lance = LocalTime.now();
        this.participante = participante;
    }

    public double getVal_lance() {
        return val_lance;
    }

    public LocalTime getHora_lance() {
        return hora_lance;
    }

    @Override
    public String toString() {
        return "Lance{" +
                "val_lance=" + val_lance +
                ", hora_lance=" + hora_lance +
                ", participante=" + participante +
                '}';
    }
}
