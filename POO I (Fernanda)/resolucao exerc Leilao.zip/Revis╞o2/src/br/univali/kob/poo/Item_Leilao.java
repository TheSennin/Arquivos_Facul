package br.univali.kob.poo;

import java.util.Stack;

public final class Item_Leilao {
    private final String titulo_item;
    private final String descricao_item;
    private final double lance_minimo;
    private final String caminho_foto;
    private int arrematado;
    private final Stack<Lance> lances;

    public Item_Leilao(String titulo_item, String descricao_item, double lance_minimo, String caminho_foto) {
        this.titulo_item = titulo_item;
        this.descricao_item = descricao_item;
        this.lance_minimo = lance_minimo;
        this.caminho_foto = caminho_foto;
        arrematado = 0;
        lances = new Stack<>();
    }

    public int lance(Lance lance){
        if(lances.empty()) {
            if(lance.getVal_lance() > lance_minimo){
                lances.add(lance);
                return 1;
            }
            return 0;
        }else {
            if (lance.getVal_lance() > lances.peek().getVal_lance()) {
                lances.add(lance);
                return 1;
            }
        }
        return 0;
    }

    public void Arrematar() {
        arrematado = 1;
    }

    public Lance getArrematador(){
        return lances.empty()? null : lances.peek();
    }

    public String getTitulo_item() {
        return titulo_item;
    }

    public String getDescricao_item() {
        return descricao_item;
    }

    public double getLance_minimo() {
        return lance_minimo;
    }

    public String getCaminho_foto() {
        return caminho_foto;
    }

    public int getArrematado() {
        return arrematado;
    }

    @Override
    public String toString() {
        return "Item_Leilao{" +
                "titulo_item='" + titulo_item + '\'' +
                ", descricao_item='" + descricao_item + '\'' +
                ", lance_minimo=" + lance_minimo +
                ", caminho_foto='" + caminho_foto + '\'' +
                ", arrematado=" + arrematado +
                ", lances=" + lances +
                '}';
    }
}
