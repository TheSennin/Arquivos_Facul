package br.univali.kob.poo;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public final class Leilao {
    private final LocalDate dt_inicio;
    private final LocalTime hor_inicio;
    private final LocalDate dt_final;
    private final LocalTime hor_final;
    private final ArrayList<Item_Leilao> itensList;

    public Leilao(LocalDate dt_inicio, LocalTime hor_inicio, LocalDate dt_final, LocalTime hor_final) {
        this.dt_inicio = dt_inicio;
        this.hor_inicio = hor_inicio;
        this.dt_final = dt_final;
        this.hor_final = hor_final;
        itensList = new ArrayList<>();
        validacaoDtHor();
    }

    private void validacaoVazia(){
        if(itensList.isEmpty()){
            throw new IllegalArgumentException("Um Leilão não pode ser criado sem nenhum item");
        }
    }

    private void validacaoDtHor(){
        if(dt_inicio.isAfter(dt_final)){
            throw new IllegalArgumentException("A data final deve ser maior que a data inicial");
        }
        if(!hor_final.isAfter(hor_inicio)){
            throw new IllegalArgumentException("A hora final deve ser maior que a hora inicial");
        }
    }

    private Item_Leilao getItensByTitulo(String titulo) {
        return itensList.stream().filter(item_leilao -> item_leilao.getTitulo_item().equals(titulo)).findFirst().orElse(null);
    }

    public void addItem(String titulo_item, String descricao_item, double lance_minimo, String caminho_foto){
        itensList.add(new Item_Leilao(titulo_item, descricao_item, lance_minimo, caminho_foto));
    }

    public int lance(String tituloItem, Lance lance){
        if(finalizaLeilao() == 0 && inciarLeilao() == 1) {
            return getItensByTitulo(tituloItem).lance(lance);
        }
        return 0;
    }

    public int inciarLeilao(){
        if(LocalDate.now().isBefore(dt_inicio)){
            return 0;
        }else {
            if(LocalTime.now().isBefore(hor_inicio)){
                return 0;
            }else {
                validacaoVazia();
            }
        }
        return 1;
    }

    public int finalizaLeilao(){
        if(!dt_final.isAfter(LocalDate.now())) {
            for (Item_Leilao item: itensList) {
                if(item.getArrematador() != null){
                    item.Arrematar();
                }
            }
            return 1;
        }
        return 0;
    }

    @Override
    public String toString() {
        return "Leilao{" +
                "dt_inicio=" + dt_inicio +
                ", hor_inicio=" + hor_inicio +
                ", dt_final=" + dt_final +
                ", hor_final=" + hor_final +
                ", itensList=" + itensList +
                '}';
    }
}
