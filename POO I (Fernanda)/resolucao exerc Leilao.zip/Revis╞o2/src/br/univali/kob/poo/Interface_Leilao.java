package br.univali.kob.poo;

public interface Interface_Leilao {
}
