package br.univali.kob.poo;

import java.util.ArrayList;

public interface Controlador_Leilao {

}
