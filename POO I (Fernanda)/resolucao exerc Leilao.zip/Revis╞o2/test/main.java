import br.univali.kob.poo.Lance;
import br.univali.kob.poo.Leilao;
import br.univali.kob.poo.Participante;
import java.time.LocalDate;
import java.time.LocalTime;

public class main {
    public static void main(String[] args) {
        Leilao leilao = new Leilao(LocalDate.of(2019,03,10),
                                   LocalTime.of(20,30),
                                   LocalDate.of(2019,03,12),
                                   LocalTime.of(20,40));
        leilao.addItem("titulo","descrição",199.99,"/src");
        Participante par = new Participante("nome","login","senha",
                                            "email","endereço","telefone");
        leilao.lance("titulo",new Lance(200,par));
        leilao.lance("titulo",new Lance(300,par));
        System.out.println(leilao.toString());
    }
}
