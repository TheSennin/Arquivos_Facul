    #include "Figura.h"


    float Figura::getArea(){
        return area;
    }
    float Figura::getPerimetro(){
        return perimetro;
    }
