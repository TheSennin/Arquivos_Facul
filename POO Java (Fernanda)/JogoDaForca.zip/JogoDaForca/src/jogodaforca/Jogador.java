/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogodaforca;

import java.util.ArrayList;

/**
 *
 * @author 6322875
 */
public class Jogador {
    /**
     * Letra chutada pelo jogador
     */
    private String letra;
    /**
     * Lista de letras chutadas pelos jogador durante o jogo;
     */
    private ArrayList<String> letrasChutadas;
    
    /**
     * Método que retorna as letras chutadas pelo jogador. 
     * @return letra chutada pelo jogador
     */
    public ArrayList getLetrasChutadas(){
        return letrasChutadas;
    };
    /**
     *@return a letra atualmente chutada pelo jogador 
     */
    public String getLetra(){
        return letra;
    };
    /**
     * Método para chutar uma letra.
     */
    public void chutaLetra(){
        //Implementar
    }
    /**
     * Método invocado ao ganhar a partida
     */
    public void ganhar(){
        //Implementar
    };
    /**
     * Método invocado ao perder uma partida.
     */
    public void perder(){
        //Implementar
    };
    /**
     * Método para adicionar letras chutadas à lista de letras
     */
    public void addLetrasChutadas(){
        //Implementar
    };
    
}
