/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogodaforca;

/**
 *
 * @author 6322875
 */
public class Boneco {
    /**
     * Parte do corpo do boneco a ser criada ao chutar uma letra inexistente
     */
    private String parte;
    
    /**
     * Método usado para desenhar a parte do boneco
     */
    public void desenha(){
        //Implementar
    }
    /**
     * Método para verificar se o boneco está completo.
     */
    public void isCompleto(){
        //Implementar
    }
}
