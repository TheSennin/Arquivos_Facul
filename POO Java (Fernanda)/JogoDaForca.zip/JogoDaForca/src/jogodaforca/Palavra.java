/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogodaforca;

import java.util.Random;

/**
 *
 * @author 6322875
 */
public class Palavra {
    /**
     * Palavra completa descoberta
     */
    private String palavraDescoberta;
    /**
     * Lista de palavras para serem usadas no jogo
     */
    private final String[] palavrasSecretas = {"Teste", "Teste2, Teste3",
        "Teste4"};
    
    /**
     * Método para checar se a letra chutada está na palavra
     * @param letra Letra chutada pelo jogador
     * @return Verdadeiro se a letra existe na palavra, Falso se a letra não existe
     */
    public boolean letraNaPalavra(String letra){
        String str = escolheSecreta();
        int n=0;
        for(int i=0;i<str.length();i++){
            n = letra.indexOf(str);
        }
        return n == -1;
    };
    /**
     * Método para desenhar a letra (caso exista)
     */
    public void desenha(){
        //Implementar
    }
    /**
     * Método para checar se a palavra está completa
     * @return Verdadeiro se a palavra estiver completa, Falso se não estiver
     */
    public boolean isCompleta(){
        return false; //Implementar
    };
    /**
     * Método para escolher uma palavra da lista de palavras secretas
     * @return a palavra escolhida
     */
    public String escolheSecreta(){
        Random rand = new Random();
        int n = rand.nextInt(4);
        return palavrasSecretas[n];
    }; 
}
