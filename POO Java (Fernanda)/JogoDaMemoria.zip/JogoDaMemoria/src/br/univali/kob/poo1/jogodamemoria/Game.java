/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univali.kob.poo1.jogodamemoria;

import br.univali.kob.poo1.controller.FXMLGameSceneController;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author 6322875
 */
public class Game {
    
    /**
     * vector that holds the card's path;
     */
    private final String cards[]={"/br/univali/kob/poo1/images/naruto.jpg",
                            "/br/univali/kob/poo1/images/kakashi.jpg",
                            "/br/univali/kob/poo1/images/minato.jpg",
                            "/br/univali/kob/poo1/images/zabuza.jpg",
                            "/br/univali/kob/poo1/images/gaara.jpg",
                            "/br/univali/kob/poo1/images/itachi.jpg",
                            "/br/univali/kob/poo1/images/madara.jpg",
                            "/br/univali/kob/poo1/images/sakura.jpg",
                            "/br/univali/kob/poo1/images/sasuke.jpg",
                            "/br/univali/kob/poo1/images/jiraya.jpg"};
    
    private String defaultCards[]={"/br/univali/kob/poo1/images/carta-virada.jpg",
                            "/br/univali/kob/poo1/images/carta-virada.jpg",
                            "/br/univali/kob/poo1/images/carta-virada.jpg",
                            "/br/univali/kob/poo1/images/carta-virada.jpg",
                            "/br/univali/kob/poo1/images/carta-virada.jpg",
                            "/br/univali/kob/poo1/images/carta-virada.jpg",
                            "/br/univali/kob/poo1/images/carta-virada.jpg",
                            "/br/univali/kob/poo1/images/carta-virada.jpg",
                            "/br/univali/kob/poo1/images/carta-virada.jpg",
                            "/br/univali/kob/poo1/images/carta-virada.jpg"};
    
    private ArrayList<String> usedCards = new ArrayList();
       
    private int moveCount;
    
    private int turnedCards;
    
    private String cardOneTurned;
    
    private String cardTwoTurned;
    
    FXMLGameSceneController fx;
    
    /**
     * Default constructor
     */
    public Game(FXMLGameSceneController f){
        moveCount = 0;
        turnedCards = 0;
        cardOneTurned = null;
        cardTwoTurned = null;
        fx = f;
        generateCards();
    }
    
    /**
     * Method used for generate cards in the moment of the instance of game class
     */
    public final void generateCards(){
        usedCards.clear();
        Random rand = new Random();
        for(int i=0;i<20;i++){    
            int index;
            do{
                index = rand.nextInt(10);
            }while(isRepeated(cards[index]));
            usedCards.add(cards[index]);
        }
    }
    
    public ArrayList getSelectedCards(){
        return usedCards;
    }
    
    public String getSelectedCardByIndex(int i){
        i = i-1;
        return usedCards.get(i);
    }
    
    public boolean turnedCards(){
        turnedCards++;

        if(turnedCards == 1){
            return true;
        }else
            if(turnedCards==2){
                moveCount++;
                return true;
            }
        else
            turnedCards = 0;
            return false;
    }
    
    public void setTurnedCards(String card){
        if(turnedCards == 1){
            cardOneTurned = card;
        }else
            if(turnedCards == 2){
                cardTwoTurned = card;
                checkSameCards();
        }
    }
    
    public boolean checkSameCards(){
        try{
            if(cardOneTurned.equals(cardTwoTurned)){
                blankCard(cardOneTurned);
                blankCard(cardTwoTurned);
                return true;
            }
        }catch(NullPointerException e){
            return false;
        }
        return false;
    }
    
    /**
     * 
     * @param card the card selected in the randomic generator in getCard().
     * @return true if is repeated more than 2 times
     */
    public boolean isRepeated(String card){
        int i;
        int counter = 0;
        for(i=0;i<usedCards.size();i++){
            if(usedCards.get(i).equals(card)){
                counter++;
            }
        }
        return counter>=2;
    }
    
    public void test(FXMLGameSceneController fx){
        Cronometer timer = new Cronometer();
        Thread t1 = new Thread(timer);
        Thread t2 = new Thread();
        

        //ver: https://www.devmedia.com.br/java-threads-utilizando-wait-notify-e-notifyall/29545

        //fx.showAllCards();
        t1.start();
        fx.showAllCards();
    }
    
    public void blankCard(String card){
            for(int i=0;i<20;i++){
                if(usedCards.get(i).equals(card)){
                    usedCards.add(i, null);
                }
            }
    }
    
    
    
    
    
    
    
    
    
    
}
