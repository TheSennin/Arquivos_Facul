/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univali.kob.poo1.controller;

import br.univali.kob.poo1.jogodamemoria.Cronometer;
import br.univali.kob.poo1.jogodamemoria.Game;
import br.univali.kob.poo1.jogodamemoria.JogoDaMemoria;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author 6322875
 */
public class FXMLGameSceneController implements Initializable {
    
    
    @FXML
    private ImageView img1;

    @FXML
    private ImageView img2;

    @FXML
    private ImageView img3;

    @FXML
    private ImageView img4;

    @FXML
    private ImageView img5;

    @FXML
    private ImageView img6;

    @FXML
    private ImageView img7;

    @FXML
    private ImageView img8;

    @FXML
    private ImageView img9;

    @FXML
    private ImageView img10;

    @FXML
    private ImageView img11;

    @FXML
    private ImageView img12;

    @FXML
    private ImageView img13;

    @FXML
    private ImageView img14;

    @FXML
    private ImageView img15;

    @FXML
    private ImageView img16;

    @FXML
    private ImageView img17;

    @FXML
    private ImageView img18;

    @FXML
    private ImageView img19;

    @FXML
    private ImageView img20;

    @FXML
    private Button btnVoltar;
    
    @FXML
    private Button btnComecar;
    
    String defaultCard = "/br/univali/kob/poo1/images/carta-virada.jpg";
            
    Game game = new Game();
    
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //TODO
    }    
    
    @FXML
    private void btnVoltarAction(ActionEvent event){
        loadImagesDefault();
        JogoDaMemoria.changeScreen("mainMenu");
    }
    
    @FXML
    private void btnComecarAction(ActionEvent event){
        //Cronometer timer = new Cronometer();
        //Thread t1 = new Thread(timer);
        
        game.generateCards();
        loadImagesDefault();
        //t1.start();
        
    }
    
    @FXML
    void loadCard1(MouseEvent event) {
        if(game.turnedCards()){
            loadCard1(game.getSelectedCardByIndex(1));
            game.setTurnedCards(game.getSelectedCardByIndex(1));
        }else{
            loadCard1(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    @FXML
    void loadCard2(MouseEvent event) {
        if(game.turnedCards()){
            loadCard2(game.getSelectedCardByIndex(2));
            game.setTurnedCards(game.getSelectedCardByIndex(2));
        }else{
            loadCard2(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    @FXML
    void loadCard3(MouseEvent event) {
        if(game.turnedCards()){
            loadCard3(game.getSelectedCardByIndex(3));
            game.setTurnedCards(game.getSelectedCardByIndex(3));
        }else{
            loadCard3(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    @FXML
    void loadCard4(MouseEvent event) {
        if(game.turnedCards()){
            loadCard4(game.getSelectedCardByIndex(4));
            game.setTurnedCards(game.getSelectedCardByIndex(4));
        }else{
            loadCard4(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    @FXML
    void loadCard5(MouseEvent event) {
        if(game.turnedCards()){
            loadCard5(game.getSelectedCardByIndex(5));
            game.setTurnedCards(game.getSelectedCardByIndex(5));
        }else{
            loadCard5(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    @FXML
    void loadCard6(MouseEvent event) {
        if(game.turnedCards()){
            loadCard6(game.getSelectedCardByIndex(6));
            game.setTurnedCards(game.getSelectedCardByIndex(6));
        }else{
            loadCard6(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    @FXML
    void loadCard7(MouseEvent event) {
        if(game.turnedCards()){
            loadCard7(game.getSelectedCardByIndex(7));
            game.setTurnedCards(game.getSelectedCardByIndex(7));
        }else{
            loadCard7(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    @FXML
    void loadCard8(MouseEvent event) {
        if(game.turnedCards()){
            loadCard8(game.getSelectedCardByIndex(8));
            game.setTurnedCards(game.getSelectedCardByIndex(8));
        }else{
            loadCard8(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    @FXML
    void loadCard9(MouseEvent event) {
        if(game.turnedCards()){
            loadCard9(game.getSelectedCardByIndex(9));
            game.setTurnedCards(game.getSelectedCardByIndex(9));
        }else{
            loadCard9(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    @FXML
    void loadCard10(MouseEvent event) {
        if(game.turnedCards()){
            loadCard10(game.getSelectedCardByIndex(10));
            game.setTurnedCards(game.getSelectedCardByIndex(10));
        }else{
            loadCard10(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    @FXML
    void loadCard11(MouseEvent event) {
        if(game.turnedCards()){
            loadCard11(game.getSelectedCardByIndex(11));
            game.setTurnedCards(game.getSelectedCardByIndex(11));
        }else{
            loadCard11(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    @FXML
    void loadCard12(MouseEvent event) {
        if(game.turnedCards()){
            loadCard12(game.getSelectedCardByIndex(12));
            game.setTurnedCards(game.getSelectedCardByIndex(12));
        }else{
            loadCard12(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    @FXML
    void loadCard13(MouseEvent event) {
        if(game.turnedCards()){
            loadCard13(game.getSelectedCardByIndex(13));
            game.setTurnedCards(game.getSelectedCardByIndex(13));
        }else{
            loadCard13(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    @FXML
    void loadCard14(MouseEvent event) {
        if(game.turnedCards()){
            loadCard14(game.getSelectedCardByIndex(14));
            game.setTurnedCards(game.getSelectedCardByIndex(14));
        }else{
            loadCard14(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    @FXML
    void loadCard15(MouseEvent event) {
        if(game.turnedCards()){
            loadCard15(game.getSelectedCardByIndex(15));
            game.setTurnedCards(game.getSelectedCardByIndex(15));
        }else{
            loadCard15(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    @FXML
    void loadCard16(MouseEvent event) {
        if(game.turnedCards()){
            loadCard16(game.getSelectedCardByIndex(16));
            game.setTurnedCards(game.getSelectedCardByIndex(16));
        }else{
            loadCard16(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    @FXML
    void loadCard17(MouseEvent event) {
        if(game.turnedCards()){
            loadCard17(game.getSelectedCardByIndex(17));
            game.setTurnedCards(game.getSelectedCardByIndex(17));
        }else{
            loadCard17(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    @FXML
    void loadCard18(MouseEvent event) {
        if(game.turnedCards()){
            loadCard18(game.getSelectedCardByIndex(18));
            game.setTurnedCards(game.getSelectedCardByIndex(18));
        }else{
            loadCard18(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    @FXML
    void loadCard19(MouseEvent event) {
        if(game.turnedCards()){
            loadCard19(game.getSelectedCardByIndex(19));
            game.setTurnedCards(game.getSelectedCardByIndex(19));
        }else{
            loadCard19(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    @FXML
    void loadCard20(MouseEvent event) {
        if(game.turnedCards()){
            loadCard20(game.getSelectedCardByIndex(20));
            game.setTurnedCards(game.getSelectedCardByIndex(20));
        }else{
            loadCard20(defaultCard);
            game.setTurnedCards(defaultCard);
        }
        if(game.checkSameCards()){
            System.out.println("Combinam");
        }else{
            System.out.println("Não Combinam");
        }
    }
    
    private void loadCard1(String path){
        img1.setImage(new Image(path));
    }
    
    private void loadCard2(String path){
        img2.setImage(new Image(path));
    }
    
    private void loadCard3(String path){
        img3.setImage(new Image(path));
    }
    
    private void loadCard4(String path){
        img4.setImage(new Image(path));
    }
    
    private void loadCard5(String path){
        img5.setImage(new Image(path));
    }
    
    private void loadCard6(String path){
        img6.setImage(new Image(path));
    }
    
    private void loadCard7(String path){
        img7.setImage(new Image(path));
    }
    
    private void loadCard8(String path){
        img8.setImage(new Image(path));
    }
    
    private void loadCard9(String path){
        img9.setImage(new Image(path));
    }
    
    private void loadCard10(String path){
        img10.setImage(new Image(path));
    }
    
    private void loadCard11(String path){
        img11.setImage(new Image(path));
    }
    
    private void loadCard12(String path){
        img12.setImage(new Image(path));
    }
    
    private void loadCard13(String path){
        img13.setImage(new Image(path));
    }
    
    private void loadCard14(String path){
        img14.setImage(new Image(path));
    }
    
    private void loadCard15(String path){
        img15.setImage(new Image(path));
    }
    
    private void loadCard16(String path){
        img16.setImage(new Image(path));
    }
    
    private void loadCard17(String path){
        img17.setImage(new Image(path));
    }
    
    private void loadCard18(String path){
        img18.setImage(new Image(path));
    }
    
    private void loadCard19(String path){
        img19.setImage(new Image(path));
    }
    
    private void loadCard20(String path){
        img20.setImage(new Image(path));
    }
    
    public void showAllCards(){
        loadCard1(game.getSelectedCardByIndex(1));
        loadCard2(game.getSelectedCardByIndex(2));
        loadCard3(game.getSelectedCardByIndex(3));
        loadCard4(game.getSelectedCardByIndex(4));
        loadCard5(game.getSelectedCardByIndex(5));
        loadCard6(game.getSelectedCardByIndex(6));
        loadCard7(game.getSelectedCardByIndex(7));
        loadCard8(game.getSelectedCardByIndex(8));
        loadCard9(game.getSelectedCardByIndex(9));
        loadCard10(game.getSelectedCardByIndex(10));
        loadCard11(game.getSelectedCardByIndex(11));
        loadCard12(game.getSelectedCardByIndex(12));
        loadCard13(game.getSelectedCardByIndex(13));
        loadCard14(game.getSelectedCardByIndex(14));
        loadCard15(game.getSelectedCardByIndex(15));
        loadCard16(game.getSelectedCardByIndex(16));
        loadCard17(game.getSelectedCardByIndex(17));
        loadCard18(game.getSelectedCardByIndex(18));
        loadCard19(game.getSelectedCardByIndex(19));
        loadCard20(game.getSelectedCardByIndex(20)); 
    }
    
    public void loadImagesDefault(){
        loadCard1(defaultCard);
        loadCard2(defaultCard);
        loadCard3(defaultCard);
        loadCard4(defaultCard);
        loadCard5(defaultCard);
        loadCard6(defaultCard);
        loadCard7(defaultCard);
        loadCard8(defaultCard);
        loadCard9(defaultCard);
        loadCard10(defaultCard);
        loadCard11(defaultCard);
        loadCard12(defaultCard);
        loadCard13(defaultCard);
        loadCard14(defaultCard);
        loadCard15(defaultCard);
        loadCard16(defaultCard);
        loadCard17(defaultCard);
        loadCard18(defaultCard);
        loadCard19(defaultCard);
        loadCard20(defaultCard);
    }
    
}
