/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univali.kob.poo1.jogodamemoria;

import br.univali.kob.poo1.controller.FXMLGameSceneController;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 6322875
 */
public class Cronometer implements Runnable{
  /**
   * Attribute to control the end of the count
   */
    private boolean endedCount;
  
    public Cronometer(){
      
    }
  
    public boolean isEndedCount(){
        return this.endedCount;
    }

    @Override
    public void run(){
        for(int i=0;i<5;i++){
            System.out.println(i);
            try {
                Thread.sleep(1000);
            }catch (InterruptedException ex) {
              Logger.getLogger(Cronometer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    
    this.endedCount = true;
    }
    
}
