#include <iostream>
#include "Fila.cpp"

using namespace std;

int main()
{
    Fila<int> fila[3];
    int numero, processosExecutados[3];
    bool particao[3];

    srand(time(NULL));

    for (int i = 0; i < 3; i++)
    {
        particao[i] = false;
        processosExecutados[i] = 0;
    }

    for (int i = 1; i <= 100; i++)
    {
        numero = rand() % 101;
        if (numero <= 25)
            fila[0].insere(1);
        else if (numero <= 39)
            fila[1].insere(1);
        else if (numero <= 49)
            fila[2].insere(1);
        else if (numero <= 75)
        {
            particao[0] = false;
            if (!(fila[0].ehVazia()))
            {
                fila[0].retira();
                particao[0] = true;
                processosExecutados[0]++;
            }
        }
        else if (numero <= 89)
        {
            particao[1] = false;
            if (!(fila[1].ehVazia()))
            {
                fila[1].retira();
                particao[1] = true;
                processosExecutados[1]++;
            }
        }
        else
        {
            particao[2] = false;
            if (!(fila[2].ehVazia()))
            {
                fila[2].retira();
                particao[2] = true;
                processosExecutados[2]++;
            }
        }
        if (i % 5 == 0)
        {
            for (int j = 0; j < 3; j++)
                cout << "fila " << j + 1 << " = " << fila[j].numeroDeElementos() << endl;
            for (int j = 0; j < 3; j++)
            {
                cout << "particao ";
                switch (j)
                {
                case 0:
                    cout << "A ";
                    break;
                case 1:
                    cout << "B ";
                    break;
                case 2:
                    cout << "C ";
                    break;
                }
                particao[j] == false ? cout << "livre" : cout << "ocupada";
                cout << endl;
            }
            for (int j = 0; j < 3; j++)
            {
                cout << "processos executados pela particao ";
                switch (j)
                {
                case 0:
                    cout << "A = ";
                    break;
                case 1:
                    cout << "B = ";
                    break;
                case 2:
                    cout << "C = ";
                    break;
                }
                cout << processosExecutados[j] << endl;
            }
            cout << endl;
        }
    }

    return 0;
}
