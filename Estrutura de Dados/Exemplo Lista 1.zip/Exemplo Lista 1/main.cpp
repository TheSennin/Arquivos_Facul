#include <iostream>

using namespace std;

typedef struct nodo
{
    int valor;
    struct nodo *proximo;
} tipoLista;

int main()
{
    tipoLista *ptraux, *ptrant, *lista = NULL;
    int i = 0;

    do
    {
        ptraux = new tipoLista;
        cout << ("Valor = ");
        cin >> ptraux->valor;

        if(lista == NULL)
            lista = ptraux;
        else
            ptrant->proximo = ptraux;
        ptrant = ptraux;
        i++;
    }
    while (i < 3);
    ptrant->proximo = NULL;

    do
    {
        ptraux = lista;
        cout << ptraux-> valor << "   ";
        lista = lista->proximo;
        delete ptraux;
    }
    while (lista != NULL);

    return 0;
}
